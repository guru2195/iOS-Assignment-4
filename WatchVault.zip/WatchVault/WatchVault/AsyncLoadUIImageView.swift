//
//  AsyncLoadUIImageView.swift
//  WatchVault
//
//  Created by Gursharan Singh on 9/12/24.
//

import UIKit

class AsyncImageView: UIImageView {
    
    static let imageCache = NSCache<NSURL, UIImage>()
    
    private var currentURL: URL?
    
    func loadImage(from url: URL) {
        
        currentURL = url
        
        if let cachedImage = AsyncImageView.imageCache.object(forKey: url as NSURL) {
            self.image = cachedImage
            return
        }
        
        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: url), let loadedImage = UIImage(data: data) {
                AsyncImageView.imageCache.setObject(loadedImage, forKey: url as NSURL)
                
                DispatchQueue.main.async {
                    if self?.currentURL == url {
                        self?.image = loadedImage
                    }
                }
            }
        }
    }
}
