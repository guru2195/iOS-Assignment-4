//
//  MovieManager.swift
//  WatchVault
//
//  Created by Gursharan Singh on 09/12/24.
//

import CoreData

class MovieManager {
    
    // Function to save movie ID to Core Data
    class func saveMovieId(movieModel: MovieModel) {
        let context = CoreDataManager.shared.context
        
        // Create a new movie entity
        let movieEntity = NSEntityDescription.insertNewObject(forEntityName: "Movie", into: context) as! Movie
        movieEntity.id = Int32(movieModel.id!)
        movieEntity.title = movieModel.title
        movieEntity.overview = movieModel.overview
        movieEntity.popularity = movieModel.popularity ?? 0
        movieEntity.release_date = movieModel.release_date
        movieEntity.poster_path = movieModel.poster_path
        
        // Save context
        do {
            try context.save()
            print("Movie ID saved successfully!")
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }
    
    // Function to fetch all saved movie IDs
    class func fetchAllMovieIds() -> [Movie] {
        let context = CoreDataManager.shared.context
        let fetchRequest: NSFetchRequest<Movie> = Movie.fetchRequest()
        
        do {
            let movies = try context.fetch(fetchRequest)
            return movies
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
            return []
        }
    }
    
    class func deleteMovieById(movieId: String) {
        let context = CoreDataManager.shared.context
        let fetchRequest: NSFetchRequest<Movie> = Movie.fetchRequest()
        
        // Filter movies by ID
        fetchRequest.predicate = NSPredicate(format: "id == %@", movieId)
        
        do {
            // Fetch the movie(s) matching the movieId
            let movies = try context.fetch(fetchRequest)
            
            // Check if movie exists and delete it
            if let movieToDelete = movies.first {
                context.delete(movieToDelete)
                try context.save()  // Save the context to persist the deletion
                print("Movie with ID \(movieId) deleted successfully!")
            } else {
                print("Movie with ID \(movieId) not found!")
            }
        } catch let error as NSError {
            print("Could not delete. \(error), \(error.userInfo)")
        }
    }
    
}
