//  MovieDetailViewController.swift
//  WatchVault
//
//  Created by Gursharan Singh on 09/12/24.
//

import UIKit

class MovieDetailViewController: UIViewController {
    
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var overviewLbl: UILabel!
    @IBOutlet weak var releaseDateLbl: UILabel!
    @IBOutlet weak var popularityLbl: UILabel!

    @IBOutlet weak var posterImg: AsyncImageView!
    
    @IBOutlet weak var bookMarkBtn: UIButton!
    
    var movieModel: MovieModel!
    
    var isMovieAlreadyBookmarked: Bool {
        get {
            if let movieModelId = movieModel.id {
                return MovieManager.fetchAllMovieIds().contains { movie in
                    movie.id == movieModelId
                }
            }
            return false
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Movie Details"
        titleLbl.text = movieModel.title
        overviewLbl.text = movieModel.overview
        releaseDateLbl.text = "Released on " + movieModel.release_date!
        popularityLbl.text = "Popularity: \(movieModel.popularity ?? 0)"
        
        if let url = movieModel.poster_path {
            posterImg.loadImage(from: URL(string: theMovieDbBasePathForImages + url)!)
        }
        configureBookmarkBtn()
    }
    
    func configureBookmarkBtn() {
        if isMovieAlreadyBookmarked {
            bookMarkBtn.setImage(UIImage(systemName: "bookmark.fill"), for: .normal)
        } else {
            bookMarkBtn.setImage(UIImage(systemName: "bookmark"), for: .normal)
        }
    }

    @IBAction func bookmarkBtnTapped(_ sender: Any) {
        if isMovieAlreadyBookmarked {
            MovieManager.deleteMovieById(movieId: "\(movieModel.id!)")
        } else {
            MovieManager.saveMovieId(movieModel: movieModel)
        }
        configureBookmarkBtn()
    }
}

