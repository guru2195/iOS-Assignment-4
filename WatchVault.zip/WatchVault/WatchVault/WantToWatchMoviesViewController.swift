//  WantToWatchMoviesViewController.swift
//  WatchVault
//
//  Created by Gursharan Singh on 09/12/24.
//

import UIKit

class WantToWatchMoviesViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
        
    var wantToWatchMovies = [MovieModel]()
        
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Bookmarked Movies"
        collectionView.keyboardDismissMode = .onDrag
        collectionView.register(UINib(nibName: "MovieCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "MovieCollectionViewCell")
        let layout = MovieFlowLayout()
        collectionView.setCollectionViewLayout(layout, animated: false)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        updateData()
    }
    
    func updateData() {
        let bookmarkedMovies = MovieManager.fetchAllMovieIds()
        wantToWatchMovies.removeAll()
        for movie in bookmarkedMovies {
            wantToWatchMovies.append(MovieModel(movie: movie))
        }
        collectionView.reloadData()
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        collectionView.collectionViewLayout.invalidateLayout()
    }
    
}

extension WantToWatchMoviesViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return wantToWatchMovies.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MovieCollectionViewCell", for: indexPath) as! MovieCollectionViewCell
        cell.setData(movie: wantToWatchMovies[indexPath.item])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let movie = wantToWatchMovies[indexPath.item]
        performSegue(withIdentifier: "toMovieDetailViewController", sender: movie)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        if let destination = segue.destination as? MovieDetailViewController {
            if let movieModel = sender as? MovieModel{
                destination.movieModel = movieModel
            }
        }
    }
}
