//
//  MovieModel.swift
//  WatchVault
//
//  Created by Gursharan Singh on 9/12/24.
//

import Foundation
import CoreData

struct MovieResultModel: Codable {
    var results: [MovieModel]
}

struct MovieModel: Codable {
    var id: Int?
    var title: String?
    var overview: String?
    var popularity: Double?
    var release_date: String?
    var poster_path: String?
    
    init(movie: Movie) {
        id = Int(movie.id)
        title = movie.title
        overview = movie.overview
        popularity = movie.popularity
        release_date = movie.release_date
        poster_path = movie.poster_path
    }
}

