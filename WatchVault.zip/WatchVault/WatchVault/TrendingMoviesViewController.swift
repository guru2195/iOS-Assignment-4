//
//  TrendingMoviesViewController.swift
//  WatchVault
//
//  Created by Gursharan Singh on 09/12/24.
//

import UIKit

let theMovieDbAPIKey: String = "38a73d59546aa378980a88b645f487fc"

let theMovieDbBasePathForImages: String = "https://image.tmdb.org/t/p/w500/"

class TrendingMoviesViewController: UIViewController {
    
    @IBOutlet weak var activityIndicatorView: UIActivityIndicatorView!
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    private var previousSearchText: String?
    
    var searchedMovieResults: [MovieModel]?
    
    var trendingMovies: [MovieModel]?

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Trending Movies"
        collectionView.keyboardDismissMode = .onDrag
        collectionView.register(UINib(nibName: "MovieCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "MovieCollectionViewCell")
        let layout = MovieFlowLayout()
        collectionView.setCollectionViewLayout(layout, animated: false)

        let rightButton = UIBarButtonItem(title: "Bookmarked", style: .plain, target: self, action: #selector(rightButtonTapped))
        navigationItem.rightBarButtonItem = rightButton
        
        fetchTrendingMovies()
    }
    
    @objc func rightButtonTapped() {
        performSegue(withIdentifier: "toWantToWatchMoviesViewController", sender: nil)
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        collectionView.collectionViewLayout.invalidateLayout()
    }

    
    func fetchTrendingMovies() {
        activityIndicatorView.startAnimating()
        fetchTrendingMovies { [weak self] movies, errorString in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.activityIndicatorView.stopAnimating()
                if let errorString {
                    let alertController = UIAlertController(title: "Error", message: errorString, preferredStyle: .alert)
                    self.present(alertController, animated: true, completion: nil)
                } else {
                    self.trendingMovies = movies
                    self.collectionView.reloadData()
                }
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        if let destination = segue.destination as? MovieDetailViewController {
            if let movieModel = sender as? MovieModel{
                destination.movieModel = movieModel
            }
        }
    }

}

extension TrendingMoviesViewController: UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        if searchBar.text?.count ?? 0 > 0 {
            collectionView.reloadData()
            activityIndicatorView.startAnimating()
            searchMovies(searchTerm: searchBar.text!) { [weak self] movies, errorString in
                guard let self = self else { return }
                DispatchQueue.main.async {
                    self.activityIndicatorView.stopAnimating()
                    if let errorString {
                        let alertController = UIAlertController(title: "Error", message: errorString, preferredStyle: .alert)
                        self.present(alertController, animated: true, completion: nil)
                    } else {
                        self.searchedMovieResults = movies
                        self.collectionView.reloadData()
                    }
                }
            }
        } else {
            self.searchedMovieResults = nil
            self.collectionView.reloadData()
        }
        searchBar.resignFirstResponder()
    }
    
}

extension TrendingMoviesViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if searchBar.text?.count ?? 0 > 0 {
            return searchedMovieResults?.count ?? 0
        } else {
            return trendingMovies?.count ?? 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MovieCollectionViewCell", for: indexPath) as! MovieCollectionViewCell
        var movies: [MovieModel]?
        if searchBar.text?.count ?? 0 > 0 {
            movies = searchedMovieResults
        } else {
            movies = trendingMovies
        }
        cell.setData(movie: movies?[indexPath.item])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        var movies: [MovieModel]?
        if searchBar.text?.count ?? 0 > 0 {
            movies = searchedMovieResults
        } else {
            movies = trendingMovies
        }
        let movie = movies?[indexPath.item]
        performSegue(withIdentifier: "toMovieDetailViewController", sender: movie)
    }
}

extension TrendingMoviesViewController {
    
    func fetchTrendingMovies(completion: @escaping ([MovieModel]?, String?) -> Void) {
        
        let urlString = "https://api.themoviedb.org/3/movie/now_playing?api_key=\(theMovieDbAPIKey)"
                
        guard let url = URL(string: urlString) else {
            completion(nil, "Invalid URL.")
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(nil, "Error fetching data: \(error.localizedDescription)")
                return
            }
            
            guard let data = data else {
                completion(nil, "No data returned.")
                return
            }
            
            let decoder = JSONDecoder()
            do {
                let movieData = try decoder.decode(MovieResultModel.self, from: data)
                print(movieData)
                completion(movieData.results, nil)
            } catch {
                completion(nil, "Error decoding data: \(error.localizedDescription)")
            }
        }
        
        task.resume()
    }
    
    func searchMovies(searchTerm: String, completion: @escaping ([MovieModel]?, String?) -> Void) {
        
        let urlString = "https://api.themoviedb.org/3/search/movie?api_key=\(theMovieDbAPIKey)&query=\(searchTerm)"
        
        guard let url = URL(string: urlString) else {
            completion(nil, "Invalid URL.")
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(nil, "Error fetching data: \(error.localizedDescription)")
                return
            }
            
            guard let data = data else {
                completion(nil, "No data returned.")
                return
            }
            
            let decoder = JSONDecoder()
            do {
                let movieData = try decoder.decode(MovieResultModel.self, from: data)
                print(movieData)
                completion(movieData.results, nil)
            } catch {
                completion(nil, "Error decoding data: \(error.localizedDescription)")
            }
        }
        task.resume()
    }

}


class MovieFlowLayout: UICollectionViewFlowLayout {
    
    override func prepare() {
        super.prepare()
        
        guard let collectionView = collectionView else { return }
        
        let isLandscape = UIDevice.current.orientation.isLandscape
        
        let spacing: CGFloat = 10

        if isLandscape {
    
            scrollDirection  = .horizontal
            
            let itemWidth = CGFloat(200)
            
            let itemHeight = collectionView.frame.height
            
            itemSize = CGSize(width: itemWidth, height: itemHeight)
        } else {
            
            scrollDirection  = .vertical
            
            let numberOfColumns: CGFloat = 1
            
            let totalSpacing = (numberOfColumns - 1) * spacing
            
            let availableWidth = collectionView.bounds.width - totalSpacing
            
            let itemWidth = availableWidth / numberOfColumns
            
            let itemHeight = itemWidth * 1.5
            
            itemSize = CGSize(width: itemWidth, height: itemHeight)
        }
        
        minimumInteritemSpacing = spacing
        minimumLineSpacing = spacing
        sectionInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
    }
}
