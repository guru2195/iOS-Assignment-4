//
//  MovieCollectionViewCell.swift
//  WatchVault
//
//  Created by Gursharan Singh on 9/12/24.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var movieImg: AsyncImageView!
    
    override func prepareForReuse() {
        super.prepareForReuse()
        movieImg.image = nil
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func setData(movie: MovieModel?) {
        if let url = movie?.poster_path {
            movieImg.loadImage(from: URL(string: theMovieDbBasePathForImages + url)!)
        }
    }

}
